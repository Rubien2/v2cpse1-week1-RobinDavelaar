#include "hwlib.hpp"

extern "C" void uart_put_char( char c ){
   hwlib::cout << c;
}

extern "C" void print_asciz(const char *s);

extern "C" void application();

extern "C" void reverse_case(char c){
   //lowercase > Uppercase
   if(c >= 97 && c <= 122){
      c = c - 32;
   }
   //Uppercase > lowercase
   else if(c >= 65 && c <= 90){
      c = c + 32;
   }
   uart_put_char(c);
} 

int main( void ){	
   
   namespace target = hwlib::target;   
    
   // wait for the PC console to start
   hwlib::wait_ms( 2000 );

   application();
}